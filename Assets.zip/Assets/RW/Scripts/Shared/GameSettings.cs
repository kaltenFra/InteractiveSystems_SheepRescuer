﻿
public static class GameSettings
{
    // Public variables
    public static HayMachineColor hayMachineColor = HayMachineColor.Blue;

}
