﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameStateManager : MonoBehaviour
{
    // Public variables
    public static GameStateManager Instance; 

    [HideInInspector]
    public int sheepSaved; 

    [HideInInspector]
    public int sheepDropped; 

    public int sheepDroppedBeforeGameOver; 
    public SheepSpawner sheepSpawner; 



    // Start is called before the first frame update
    void Awake()
    {
        Instance = this;

    }


    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            SceneManager.LoadScene("Title");
        }

    }


    // Count saved sheeps and display number.
    public void SavedSheep()
    {
        sheepSaved++;
        UIManager.Instance.UpdateSheepSaved();
    }


    // End current game and return to start screen.
    private void GameOver()
    {
        sheepSpawner.canSpawn = false; 
        sheepSpawner.DestroyAllSheep(); 
        UIManager.Instance.ShowGameOverWindow();

    }


    // Count dropped sheep and display number. 
    //  End current game if max. drop count reached.
    public void DroppedSheep()
    {
        sheepDropped++; 
        UIManager.Instance.UpdateSheepDropped();

        /* Note: Somehow, for each sheep that falls off the edge the 
            sheepDropped Counter increases by 2 instead of 1. Thus, the 
            Game is over if twice as many sheep were recorded flying off 
            the edge as the corresponding value allows. */
        if (sheepDropped == 2*sheepDroppedBeforeGameOver) 
        {
            GameOver();
        }
    }


}

