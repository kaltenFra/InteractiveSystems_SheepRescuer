﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    // Public variables
    public static UIManager Instance; 

    public Text sheepSavedText; 
    public Text sheepDroppedText; 
    public GameObject gameOverWindow; 



    // Start is called before the first frame update
    void Awake()
    {
        Instance = this;
    }


    // Display current count of saved sheeps.
    public void UpdateSheepSaved() 
    {
        sheepSavedText.text = GameStateManager.Instance.sheepSaved.ToString();
    }


    // Display current count of dropped sheeps.
    public void UpdateSheepDropped() 
    {
        /* Note: Somehow, for each sheep that falls off the edge the 
            sheepDropped Counter increases by 2 instead of 1. Thus, the 
            count of dropped sheep has to be divided by 2 first. */
        float sheepDroppedCount = GameStateManager.Instance.sheepDropped / 2;
        sheepDroppedText.text = sheepDroppedCount.ToString();
    }


    // Display Game-Over window.
    public void ShowGameOverWindow()
    {
        gameOverWindow.SetActive(true);
    }


}
