﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyOnTrigger : MonoBehaviour
{
    // Public variables
    public string tagFilter;



    // Check for colisions with Destroy-Collider and perform actions accordingly.
    private void OnTriggerEnter (Collider other)
    {
        if (other.CompareTag(tagFilter))
        {
            Destroy(gameObject);
        }
    }
}
