﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class ChangeColorOnMouseOver : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    // Public variables
    public MeshRenderer model; 
    public Color normalColor; 
    public Color hoverColor; 



    // Start is called before the first frame update
    void Start()
    {
        model.material.color = normalColor;
    }


    // Check for mouse-entering and perform actions accordingly.
    public void OnPointerEnter(PointerEventData eventData) 
    {
        model.material.color = hoverColor;
    }


    // Check for mouse-exiting and perform actions accordingly.
    public void OnPointerExit(PointerEventData eventData) 
    {
        model.material.color = normalColor;
    }

}
