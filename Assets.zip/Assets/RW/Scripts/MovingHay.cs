﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingHay : MonoBehaviour
{   
    // Public variables
    public GameObject limitRight; 
    public GameObject limitLeft;

    // Hay Bale Configurations
    public float movementSpeed;
    public GameObject hayBalePrefab; // reference to HayBale prefab
    public Transform haySpawnpoint; // point from where to shot the hay
    public float shootInterval; // smallest amount of time between shots

    // Hay Machine models
    public Transform modelParent; 

    public GameObject blueModelPrefab;
    public GameObject yellowModelPrefab;
    public GameObject redModelPrefab;


    // Private variables
    private float shootTimer; // timer tracking whether the machine can shot



    // Start is called before the first frame update
    void Start()
    {
        LoadModel();
    }


    // Load the hay machine model selected by the user.
    private void LoadModel()
    {
        Destroy(modelParent.GetChild(0).gameObject); 

        switch (GameSettings.hayMachineColor) 
        {
            case HayMachineColor.Blue:
                Instantiate(blueModelPrefab, modelParent);
            break;

            case HayMachineColor.Yellow:
                Instantiate(yellowModelPrefab, modelParent);
            break;

            case HayMachineColor.Red:
                Instantiate(redModelPrefab, modelParent);
            break;
        }
    }


    // Update is called once per frame
    void Update()
    {
        UpdateMovement();

        UpdateShooting();

    }


    // Updates current possition according to movement.
    private void UpdateMovement()
    {
        float hoizontalInput = Input.GetAxisRaw("Horizontal");

        if(hoizontalInput < 0 
            && transform.position.x > limitLeft.transform.position.x + 3.5)
        {
            transform.Translate(-transform.right * movementSpeed * Time.deltaTime);
        }   
        if(hoizontalInput > 0 
            && transform.position.x < limitRight.transform.position.x - 3.5)
        {
            transform.Translate(transform.right * movementSpeed * Time.deltaTime);
        }
    }


    // Initialize shot on pressed Space-Key.
    private void UpdateShooting() 
    {
        shootTimer -= Time.deltaTime; 

        if (shootTimer <= 0 && Input.GetKey(KeyCode.Space))
        {
            shootTimer = shootInterval;
            ShootHay();
        }
    }


    // Create new hay and shot it.
    private void ShootHay()
    {
        Instantiate(hayBalePrefab, haySpawnpoint.position, Quaternion.identity);

        // sound
        SoundManager.Instance.PlayShootClip();

    }
}
